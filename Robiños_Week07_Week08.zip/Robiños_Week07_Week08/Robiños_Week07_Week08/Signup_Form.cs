﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Robiños_Week07_Week08
{
    public partial class Signup_Form : Form
    {
        public Signup_Form()
        {
            InitializeComponent();
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            // Keep this if you are using a MaskedTextBox
        }

        // Function/Event handler when the Submit button is clicked
        private void button1_Click(object sender, EventArgs e)
        {
            // Retrieve values from textboxes 
            // (textBox1 = Full Name, textBox2 = E-mail, textBox3 = Username, textBox4 = Password)
            string fullName = fullname.Text.Trim();
            string email = this.email.Text.Trim();
            string username = this.username.Text.Trim();
            string password = this.password.Text;

            // 1. Validation: Check if fields are empty
            if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(email) ||
                string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please fill in all the required fields.", "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 2. Validation: Basic email format check
            if (!email.Contains("@") || !email.Contains("."))
            {
                MessageBox.Show("Please enter a valid email address.", "Invalid Email",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 3. Success Message
            MessageBox.Show($"Signup Successful!\n\n" +
                            $"Full Name: {fullName}\n" +
                            $"E-mail: {email}\n" +
                            $"Username: {username}",
                            "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

           
            ClearFormFields();
        }


        private void ClearFormFields()
        {
            
            txtFullName.Clear();
            txtEmail.Clear();
            txtUsername.Clear();
            txtPassword.Clear();
            txtFullName.Focus();
        }
        private void Signup_Form_Load(object sender, EventArgs e)
        {

        }
    }
}