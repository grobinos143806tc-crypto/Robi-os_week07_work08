﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Catana_Week07_Week08
{
    public partial class SHOP_Inventory : Form
    {
        public SHOP_Inventory()
        {
            InitializeComponent();
        }
    }
}
